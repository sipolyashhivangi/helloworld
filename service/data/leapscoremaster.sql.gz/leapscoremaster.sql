-- MySQL dump 10.13  Distrib 5.5.37, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: leapscoremaster
-- ------------------------------------------------------
-- Server version	5.5.37-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accesstoken`
--

DROP TABLE IF EXISTS `accesstoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accesstoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The ID of the Token',
  `accesstoken` varchar(200) NOT NULL COMMENT 'The access token ',
  `max` int(11) NOT NULL COMMENT 'The max that can be used with this token',
  `current` int(11) NOT NULL COMMENT 'number of people signed up with this token',
  `userinfo` longtext NOT NULL COMMENT 'The user info of the user/company that this token is given into',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accesstoken`
--

LOCK TABLES `accesstoken` WRITE;
/*!40000 ALTER TABLE `accesstoken` DISABLE KEYS */;
INSERT INTO `accesstoken` VALUES (1,'wslsfs',1000000,0,''),(2,'flexfriends101',10200,0,'Token created for release on june 12 1052 IST'),(4,'flexfriend897',500,0,'added on July 11 1202 hours IST : Advised by Melroy'),(5,'sftechflex',200,0,'SF NewTech Demo on July 24 2013'),(6,'IMAFLEXERNOW',1000,0,'August 8th Request by Sarah'),(7,'imaflexernow',100,0,'August 8th Request by Sarah'),(8,'lisaflex',5,0,'Lisa from Kiplingers - Reporter August 20 2013'),(9,'KIPFLEXSCORE',5000,0,'Kiplingers - Reporter August 22 2013'),(10,'FBFLEX',10000,0,'For Facebook Fans August 26 2013'),(11,'MTTEST',5000,0,'For Mechanical Turk August 26 2013'),(12,'modbee',2000,0,'Requested by Jeff and Jason Sept 10');
/*!40000 ALTER TABLE `accesstoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actionstep`
--

DROP TABLE IF EXISTS `actionstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actionstep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `actionsteps` text COLLATE utf8_unicode_ci NOT NULL,
  `actionstatus` enum('0','1','2','3','4','5') COLLATE utf8_unicode_ci NOT NULL COMMENT '0=new,1=completed,2=viewed,3=started,4=history,5=deleted',
  `type` enum('short','instant','mid') COLLATE utf8_unicode_ci NOT NULL,
  `lastmodifiedtime` datetime NOT NULL,
  `actionid` int(15) NOT NULL,
  `points` int(2) NOT NULL,
  `userorder` int(11) NOT NULL,
  `flexi1` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'store actiondetails',
  `flexi2` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'store percentage values',
  `flexi3` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'store link id values',
  `flexi5` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'store $amount from SE',
  `advisorhelpstatus` enum('0','1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT '0 = New, 1 = Advisor Notified, 2 = Sent mail to Advisor',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`actionid`)
) ENGINE=InnoDB AUTO_INCREMENT=765554 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Action step for each consumer and linked with actionstepmeta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actionstep`
--

LOCK TABLES `actionstep` WRITE;
/*!40000 ALTER TABLE `actionstep` DISABLE KEYS */;
/*!40000 ALTER TABLE `actionstep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminadvisors`
--

DROP TABLE IF EXISTS `adminadvisors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminadvisors` (
  `advisor_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adminasrecommendation`
--

DROP TABLE IF EXISTS `adminasrecommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminasrecommendation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `action_id` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_description` text NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `createdtimestamp` datetime NOT NULL,
  `product_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adv_designations`
--

DROP TABLE IF EXISTS `adv_designations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adv_designations` (
  `advisor_id` int(11) NOT NULL,
  `desig_name` varchar(250) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `createdat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `adv_desig_id` int(10) NOT NULL AUTO_INCREMENT,
  `other` int(5) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`adv_desig_id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisor`
--

DROP TABLE IF EXISTS `advisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleid` int(4) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `city` varchar(15) NOT NULL,
  `state` varchar(15) NOT NULL,
  `zip` int(6) NOT NULL,
  `isactive` enum('0','1','2') NOT NULL COMMENT '0->Inactive, 1-Active and 2-Disabled',
  `resetpasswordcode` varchar(100) NOT NULL,
  `resetpasswordexpiration` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'time that the reset password code will expire',
  `createdby` varchar(225) NOT NULL,
  `verificationcode` varchar(50) NOT NULL,
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastaccesstimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `requestinvitetokenkey` varchar(225) NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `unsubscribecode` varchar(255) DEFAULT NULL,
  `passwordupdated` tinyint(4) NOT NULL DEFAULT '0',
  `advidhashvalue` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=latin1 COMMENT='Used to check if admin has verified this advisor';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisoraccess`
--

DROP TABLE IF EXISTS `advisoraccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisoraccess` (
  `id` int(16) unsigned NOT NULL AUTO_INCREMENT,
  `advisor_id` int(11) unsigned NOT NULL,
  `attempt` tinyint(2) NOT NULL COMMENT '0=failed, 1=success',
  `accesstimestamp` datetime NOT NULL,
  `current` tinyint(2) NOT NULL COMMENT '0=false, 1=true',
  PRIMARY KEY (`id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=345 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisorasrecommendation`
--

DROP TABLE IF EXISTS `advisorasrecommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisorasrecommendation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advisor_id` int(11) NOT NULL,
  `actionid` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_link` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastaccesstimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisornotification`
--

DROP TABLE IF EXISTS `advisornotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisornotification` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The row ID',
  `advisor_id` int(11) NOT NULL,
  `refid` int(11) NOT NULL COMMENT 'The FILOGINACCT ID',
  `rowid` int(11) NOT NULL COMMENT 'This wil be row ID from CashEdge Item table, and will keep changing if the row is deleted',
  `info` varchar(100) NOT NULL COMMENT 'This will contain the FI Name, and FI id',
  `message` varchar(100) NOT NULL COMMENT 'The message description that is displayed in the notification bar.',
  `context` varchar(25) NOT NULL COMMENT 'The context in which they are sent, they will also be declared as public variabled in CashEdge controller',
  `template` varchar(25) NOT NULL COMMENT 'The template that is needed to render the message',
  `status` int(1) NOT NULL COMMENT 'Will be either 0 or 1 , based on the condition',
  `lastmodified` datetime NOT NULL COMMENT 'last modified timestamp ($timestamp = date("Y-m-d H:i:s")) through code',
  `batchcode` int(10) NOT NULL COMMENT 'The error code from batchfile ',
  `batchmodified` datetime NOT NULL COMMENT 'The timestamp of the last batchcode update ($timestamp = date("Y-m-d H:i:s"))',
  `file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=390 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisorpersonalinfo`
--

DROP TABLE IF EXISTS `advisorpersonalinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisorpersonalinfo` (
  `advisor_id` int(11) NOT NULL,
  `firstname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `advisortype` enum('Broker','Advisor','Both') COLLATE utf8_unicode_ci NOT NULL,
  `firmname` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `designation` text COLLATE utf8_unicode_ci NOT NULL,
  `areaofspez` text COLLATE utf8_unicode_ci NOT NULL,
  `stateregistered` text COLLATE utf8_unicode_ci NOT NULL,
  `avgacntbalanceperclnt` decimal(20,2) NOT NULL,
  `minasstsforpersclient` decimal(20,2) NOT NULL,
  `typeofcharge` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flexi1` text COLLATE utf8_unicode_ci NOT NULL,
  `flexi2` text COLLATE utf8_unicode_ci NOT NULL,
  `flexi3` text COLLATE utf8_unicode_ci NOT NULL,
  `profilepic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `individualcrd` int(11) DEFAULT NULL,
  PRIMARY KEY (`advisor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advisorpersonalinfo`
--

LOCK TABLES `advisorpersonalinfo` WRITE;
/*!40000 ALTER TABLE `advisorpersonalinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `advisorpersonalinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advisorstates`
--

DROP TABLE IF EXISTS `advisorstates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisorstates` (
  `advisor_id` int(11) NOT NULL,
  `stateregistered` int(10) NOT NULL,
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3378 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisorsubscription`
--

DROP TABLE IF EXISTS `advisorsubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisorsubscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The row ID',
  `advisor_id` int(11) NOT NULL,
  `stripecustomerid` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `stripesubscriptionid` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `stripecardid` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `planname` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `subscriptionstart` datetime DEFAULT NULL COMMENT 'overall subscription start date',
  `subscriptionend` datetime DEFAULT NULL COMMENT 'overall subscription end date',
  `processor` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Payment processor, currently stripe or flexscore',
  `cardexpirationdate` datetime DEFAULT NULL,
  `cardlast4` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Credit card last four digits',
  `cardtype` varchar(55) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Credit card type (Visa, Amex, etc.)',
  `currentperiodstart` datetime DEFAULT NULL COMMENT 'subscription current period start date',
  `currentperiodend` datetime DEFAULT NULL COMMENT 'subscription current period end date',
  `stripestatus` varchar(55) DEFAULT NULL COMMENT 'Status returned from Stripe.',
  `modifiedtimestamp` timestamp NULL DEFAULT NULL,
  `cardexpiredemail` datetime DEFAULT NULL COMMENT 'Indicates when most recent email re expiring credit card was sent.',
  `cardnotauthorizedemail` datetime DEFAULT NULL COMMENT 'Indicates when most recent email re unauthorized credit card was sent.',
  PRIMARY KEY (`id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 COMMENT='Used for access to advisor system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `advisorsubscriptioninvoice`
--

DROP TABLE IF EXISTS `advisorsubscriptioninvoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisorsubscriptioninvoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `advisor_id` int(11) NOT NULL,
  `flexscoreinvoicenumber` varchar(55) NOT NULL,
  `stripeinvoicenumber` varchar(55) NOT NULL,
  `status` varchar(10) NOT NULL,
  `invoicedate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `analytics`
--

DROP TABLE IF EXISTS `analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL,
  `details` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=698 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics`
--

LOCK TABLES `analytics` WRITE;
/*!40000 ALTER TABLE `analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'This is the ID / Serial Number of the table',
  `user_id` int(11) NOT NULL,
  `refid` int(11) NOT NULL COMMENT 'This is the cash edge reference ID used for connected accounts',
  `context` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'This stores if the account is manually entered or obtained from cashedge through connect accounts',
  `FILoginAcctId` int(100) NOT NULL COMMENT 'This is the FILoginAcctId from the leapscoremeta.cashedgeitem table',
  `accttype` varchar(100) NOT NULL COMMENT 'This is the classification code from CE',
  `type` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'It is first 3 aplhabets of the type of asset',
  `subtype` varchar(255) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'This is the name of the type of the account / asset',
  `actid` varchar(150) NOT NULL COMMENT 'account id from cashedge',
  `balance` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The balance amount that you have',
  `beneficiary` tinyint(1) NOT NULL COMMENT 'Beneficiaries Listed and Up to Date: Yes-1, No-0, Not Sure-2',
  `contribution` decimal(16,4) NOT NULL COMMENT 'The amount contributed by you in the case of this asset type',
  `growthrate` decimal(8,4) NOT NULL COMMENT 'The growth rate in percentage per year',
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'The address, address2, city and state concatenated by gg',
  `zipcode` varchar(15) NOT NULL COMMENT 'The zipcode of the address of the user',
  `empcontribution` decimal(8,4) NOT NULL COMMENT 'The percentage amount contributed by the employer for this asset type',
  `withdrawal` decimal(16,4) NOT NULL COMMENT 'The monthly withdrawal amount for this asset type',
  `livehere` int(11) NOT NULL COMMENT 'Does user live at this asset',
  `assettype` smallint(1) NOT NULL COMMENT 'The code from the OTLT table',
  `netincome` decimal(16,4) NOT NULL COMMENT 'The net income for the PROPERTY asset type',
  `loan` decimal(16,4) NOT NULL COMMENT 'The loan on the asset if any on the PROPERTY or VEHICLE section',
  `agepayout` tinyint(2) NOT NULL COMMENT 'Earliest age you anticipate beginning payout in the PENSION SECTION',
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'downloaded timestamp for auto account',
  `modifiedtimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'This get updated when Batch file update this account.',
  `ticker` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'ticker from investment account from getpos call',
  `invpos` text NOT NULL COMMENT 'stores json format of invpos ticker',
  `classified` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'This column specifies if this investment type is classified or not',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-active, 1-deleted, 2-hidden',
  `priority` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `status` (`status`),
  KEY `type` (`type`),
  KEY `livehere` (`livehere`),
  KEY `balance` (`balance`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63788 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `breakdownchange`
--

DROP TABLE IF EXISTS `breakdownchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `breakdownchange` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `goal` int(11) DEFAULT NULL,
  `savings` int(11) DEFAULT NULL,
  `assets` int(11) DEFAULT NULL,
  `debts` int(11) DEFAULT NULL,
  `living` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `id` char(128) NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `value` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashedgeaccount`
--

DROP TABLE IF EXISTS `cashedgeaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashedgeaccount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(256) DEFAULT NULL,
  `cpassword` varchar(100) DEFAULT NULL,
  `ceuserid` int(11) DEFAULT NULL,
  `cutype` enum('Admin','Customer') DEFAULT 'Customer',
  `sesinfo` text,
  `timemodified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'The time in which this table was last updated.',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4772 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashedgeaccount`
--

LOCK TABLES `cashedgeaccount` WRITE;
/*!40000 ALTER TABLE `cashedgeaccount` DISABLE KEYS */;
/*!40000 ALTER TABLE `cashedgeaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashedgeitem`
--

DROP TABLE IF EXISTS `cashedgeitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashedgeitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `Fiid` int(11) NOT NULL,
  `RunId` int(11) NOT NULL,
  `HarvestID` int(11) NOT NULL,
  `HarvestAddID` varchar(255) NOT NULL,
  `FILoginAcctId` int(11) NOT NULL,
  `AcctHarvestStatus` varchar(255) NOT NULL,
  `ClassifiedStatus` varchar(255) NOT NULL,
  `lsstatus` smallint(6) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-active, 1-deleted',
  `msg` varchar(255) NOT NULL COMMENT 'message returned by the FI',
  `mfa` tinyint(4) DEFAULT '0',
  `accountdetails` text,
  `accountpending` longtext,
  `lsupdate` int(11) NOT NULL DEFAULT '0' COMMENT 'update account status 0 - updated, 1 - tobe updated',
  `cecheck` int(4) NOT NULL COMMENT 'This is for answering the security question wrongly',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'This is to check if the account is deleted or not.',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28889 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashedgeitem`
--

LOCK TABLES `cashedgeitem` WRITE;
/*!40000 ALTER TABLE `cashedgeitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `cashedgeitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celog`
--

DROP TABLE IF EXISTS `celog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `celog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `flloginacctid` int(11) NOT NULL,
  `acctid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21961 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celog`
--

LOCK TABLES `celog` WRITE;
/*!40000 ALTER TABLE `celog` DISABLE KEYS */;
/*!40000 ALTER TABLE `celog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constants`
--

DROP TABLE IF EXISTS `constants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `constants` (
  `constantid` int(10) NOT NULL,
  `constantname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `constanttype` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `constantvalue` int(15) NOT NULL,
  `startdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `enddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`constantid`),
  UNIQUE KEY `id` (`constantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `consumervsadvisor`
--

DROP TABLE IF EXISTS `consumervsadvisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumervsadvisor` (
  `user_id` int(11) NOT NULL,
  `advisor_id` int(11) NOT NULL,
  `permission` enum('RO','RW','N') COLLATE utf8_unicode_ci NOT NULL,
  `dateconnect` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-pending 1-accept',
  `indemnification_check` int(3) NOT NULL DEFAULT '0',
  `phone` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `topic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` int(1) NOT NULL,
  `message` varchar(650) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`,`advisor_id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debts` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary key for this table',
  `user_id` int(11) NOT NULL,
  `refid` int(11) NOT NULL COMMENT 'refid for the cash edge',
  `type` varchar(100) NOT NULL COMMENT 'The type of the debts',
  `context` varchar(50) NOT NULL DEFAULT 'Manual',
  `FILoginAcctId` int(100) NOT NULL COMMENT 'This is the FILoginAcctId from the leapscoremeta.cashedgeitem table',
  `accttype` varchar(100) NOT NULL COMMENT 'This is the classification code from CE',
  `subtype` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL COMMENT 'name of the debt ',
  `actid` varchar(200) NOT NULL COMMENT 'account id from cashedge',
  `balowed` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The balance amount owed totally',
  `amtpermonth` decimal(16,4) NOT NULL COMMENT 'Amount payable per month',
  `apr` decimal(8,4) NOT NULL COMMENT 'It is the interest rate of the debt per month',
  `yearsremaining` int(11) NOT NULL COMMENT 'Number of years remaining for the debts to get over',
  `intdeductible` tinyint(1) NOT NULL COMMENT 'Is the interest deductible or not',
  `mortgagetype` varchar(50) NOT NULL COMMENT 'The mortgage type ',
  `livehere` tinyint(1) NOT NULL COMMENT 'Do you live here or not',
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'downloaded timestamp for auto account',
  `modifiedtimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'This get updated when Batch file update this account.',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-active, 1-deleted, 2-hidden',
  `monthly_payoff_balances` tinyint(1) NOT NULL DEFAULT '0',
  `priority` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30499 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `os` varchar(45) NOT NULL COMMENT 'Device OS',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1440 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `echouser`
--

DROP TABLE IF EXISTS `echouser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `echouser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `permission` enum('0','1','2') DEFAULT NULL COMMENT '0 = not answered, 1 = accepted, or 2 = declined',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emailmaster`
--

DROP TABLE IF EXISTS `emailmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailmaster` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fromaddress` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `toaddress` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Sent','Pending','Error') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Pending',
  `que` int(1) NOT NULL DEFAULT '0',
  `enddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3420 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `estimation`
--

DROP TABLE IF EXISTS `estimation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimation` (
  `user_id` int(11) NOT NULL,
  `houseincome` decimal(12,2) NOT NULL COMMENT 'Estimated household income for the month',
  `houseexpense` decimal(12,2) NOT NULL COMMENT 'Estimated household expense for the month',
  `houseassets` decimal(12,2) NOT NULL COMMENT 'Estimated household assets',
  `housedebts` decimal(12,2) NOT NULL COMMENT 'Estimated household debts',
  `housesavings` decimal(12,2) NOT NULL COMMENT 'Estimated House hold savings',
  `whichyouhave` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense` (
  `user_id` int(11) NOT NULL,
  `actualexpense` decimal(20,2) NOT NULL,
  `rentmortgage` decimal(12,2) NOT NULL COMMENT 'This is the mortgage amount',
  `utilities` decimal(12,2) NOT NULL COMMENT 'This is the amount for the utilities',
  `groceries` decimal(12,2) NOT NULL COMMENT 'This is the amount spent for groceries',
  `gastransportation` decimal(12,2) NOT NULL COMMENT 'This is used for gas / transport',
  `entertainment` decimal(12,2) NOT NULL COMMENT 'This is used for enterntainment',
  `household` decimal(12,2) NOT NULL COMMENT 'This is the household expenses',
  `health` decimal(12,2) NOT NULL COMMENT 'This is the money spent on healthcare',
  `cardloadpmnts` decimal(12,2) NOT NULL COMMENT 'This is the amount, paid for card payments',
  `taxes` decimal(12,2) NOT NULL COMMENT 'This money denotes the tax paid',
  `travel` decimal(12,2) NOT NULL COMMENT 'This is the money for travel',
  `other` decimal(12,2) NOT NULL COMMENT 'Any other expenes incurred will come under here',
  `createdupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `filemanagement`
--

DROP TABLE IF EXISTS `filemanagement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filemanagement` (
  `fid` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filename` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `filepath` text COLLATE utf8_unicode_ci NOT NULL,
  `filetype` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'Mime type of the file. An example would be "image/gif". ',
  `filesize` int(10) NOT NULL,
  `filetemporaryname` text COLLATE utf8_unicode_ci NOT NULL COMMENT ' The temporary filename of the file in which the uploaded file was stored on the server. ',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `fid` (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `goal`
--

DROP TABLE IF EXISTS `goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `goalname` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `goaldescription` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `goaltype` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `goalpriority` int(2) NOT NULL,
  `goalamount` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The goal amount that you have',
  `collegeyears` int(15) NOT NULL,
  `permonth` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The permonth amount that you have',
  `goalstartdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `goalenddate` date NOT NULL,
  `saved` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The amount saved for the goal',
  `downpayment` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The downpayment saved for the goal',
  `goalimage` tinyblob NOT NULL,
  `goalstatus` int(11) NOT NULL,
  `payoffdebts` text NOT NULL COMMENT 'stores debt ids incase of pay off debt goal',
  `monthlyincome` decimal(16,4) NOT NULL DEFAULT '0.0000' COMMENT 'The monthly income that you have',
  `modifiedtimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `goalassumptions_1` varchar(10) DEFAULT NULL,
  `goalassumptions_2` varchar(50) DEFAULT NULL,
  `contributions` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `minimumContributions` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48938 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `income`
--

DROP TABLE IF EXISTS `income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income` (
  `no` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Serial Number',
  `user_id` int(11) NOT NULL,
  `totaluserincome` decimal(20,2) NOT NULL,
  `gross_income` decimal(20,2) NOT NULL COMMENT 'The gross income of the user',
  `investment_income` decimal(20,2) NOT NULL COMMENT 'The income due to investments made',
  `spouse_income` decimal(20,2) NOT NULL COMMENT 'The income of the spouse, fill it up if any',
  `retirement_plan` decimal(20,2) NOT NULL COMMENT 'The amount got on retirement plan distributions',
  `pension_income` decimal(20,2) NOT NULL COMMENT 'The pension amount',
  `social_security` decimal(20,2) NOT NULL COMMENT 'The amount received from social security',
  `disability_benefit` decimal(20,2) NOT NULL COMMENT 'The amount received by disability cheques',
  `veteran_income` decimal(20,2) NOT NULL COMMENT 'The amount got by the veteran , military pension',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'The timestamp of the creation of this row',
  `modified_on` timestamp NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The last modified time of this row',
  PRIMARY KEY (`no`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11486 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance`
--

DROP TABLE IF EXISTS `insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The is the primary key',
  `user_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL COMMENT 'This is the type of the insurance : life, disabilty .. etc',
  `subtype` varchar(200) NOT NULL,
  `annualpremium` decimal(16,4) NOT NULL COMMENT 'This is the annual premium amount paid by the user',
  `cashvalue` decimal(16,4) NOT NULL COMMENT 'is the cash-value of the policy',
  `reviewyear` int(11) NOT NULL COMMENT 'The year in which the insurance was last reviewed',
  `name` varchar(100) NOT NULL COMMENT 'Name of the insurance',
  `actid` varchar(200) NOT NULL COMMENT 'account id from cashedge',
  `dailybenfitamt` decimal(16,4) NOT NULL COMMENT 'The daily benefit amount related to Long term insurance',
  `policyendyear` int(11) NOT NULL COMMENT 'The year that the current policy ends',
  `coverageamt` decimal(16,4) NOT NULL COMMENT 'This is the insurance coverage amount on your annual income / percentage',
  `lifeinstype` tinyint(1) NOT NULL COMMENT 'This is the life insurance type',
  `amtupondeath` decimal(16,4) NOT NULL COMMENT 'This is the amount that you get upon your death from the insurance that you have : Life insurance only',
  `deductible` decimal(16,4) NOT NULL COMMENT 'This is the deductible in the Vehicle insurance',
  `grouppolicy` tinyint(1) NOT NULL COMMENT 'private / employer group policy : Disability insurance',
  `insurancefor` varchar(25) NOT NULL COMMENT 'Who Owns Policy',
  `beneficiary` varchar(100) NOT NULL,
  `dailyamtindexed` tinyint(1) NOT NULL COMMENT 'Daily amt indexed for inflation T/F : Long Term',
  `refid` int(11) NOT NULL COMMENT 'This is the ref ID for the Cash Edge',
  `context` varchar(7) NOT NULL COMMENT 'Whether it is manual / connect',
  `FILoginAcctId` int(100) NOT NULL COMMENT 'This is the FILoginAcctId from the leapscoremeta.cashedgeitem table',
  `accttype` varchar(100) NOT NULL COMMENT 'This is the classification code from CE',
  `ticker` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'ticker from investment account from getpos call',
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'downloaded timestamp for auto account',
  `modifiedtimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'This get updated when Batch file update this account.',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-active, 1-deleted, 2-hidden',
  `priority` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `cashvalue` (`cashvalue`),
  KEY `status` (`status`),
  KEY `lifeinstype` (`lifeinstype`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23028 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logdb`
--

DROP TABLE IF EXISTS `logdb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logdb` (
  `user_id` int(11) NOT NULL,
  `moduleid` int(10) NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `logdb_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `miscellaneous`
--

DROP TABLE IF EXISTS `miscellaneous`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `miscellaneous` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `taxpay` varchar(20) NOT NULL,
  `taxbracket` varchar(20) NOT NULL,
  `taxvalue` varchar(20) NOT NULL,
  `taxcontri` varchar(10) NOT NULL,
  `taxStdOrItemDed` varchar(10) NOT NULL,
  `misctrust` varchar(10) NOT NULL,
  `miscreviewmonth` varchar(20) NOT NULL,
  `miscreviewyear` varchar(10) NOT NULL,
  `mischiddenasset` varchar(10) NOT NULL,
  `miscrightperson` varchar(10) NOT NULL,
  `miscliquid` varchar(10) NOT NULL,
  `miscspouse` varchar(10) NOT NULL,
  `moremoney` varchar(20) NOT NULL,
  `moreinvrebal` varchar(10) NOT NULL,
  `moreautoinvest` varchar(10) NOT NULL,
  `moreliquidasset` varchar(10) NOT NULL,
  `morecharity` varchar(10) NOT NULL,
  `morecreditscore` varchar(10) NOT NULL,
  `morereviewmonth` varchar(20) NOT NULL,
  `morescorereviewyear` varchar(10) NOT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9769 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `montecarlouser`
--

DROP TABLE IF EXISTS `montecarlouser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `montecarlouser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `montecarloprobability` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `futureincome` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'The time of the first MC request',
  `modifiedtimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Latest MC request',
  `lastruntimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Last time MC ran for the user',
  `failedruns` int(4) DEFAULT '0' COMMENT 'Counts consecutive failed runs',
  `lastfailedtimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Time of last failed run',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11766 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `networth`
--

DROP TABLE IF EXISTS `networth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `val` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43526 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The row ID',
  `user_id` int(11) NOT NULL,
  `refid` int(11) NOT NULL COMMENT 'The FILOGINACCT ID',
  `rowid` int(11) NOT NULL COMMENT 'This wil be row ID from CashEdge Item table, and will keep changing if the row is deleted',
  `info` varchar(100) NOT NULL COMMENT 'This will contain the FI Name, and FI id',
  `message` varchar(100) NOT NULL COMMENT 'The message description that is displayed in the notification bar.',
  `context` varchar(25) NOT NULL COMMENT 'The context in which they are sent, they will also be declared as public variabled in CashEdge controller',
  `template` varchar(25) NOT NULL COMMENT 'The template that is needed to render the message',
  `status` int(1) NOT NULL COMMENT 'Will be either 0 or 1 , based on the condition',
  `lastmodified` datetime NOT NULL COMMENT 'last modified timestamp ($timestamp = date("Y-m-d H:i:s")) through code',
  `batchcode` int(10) NOT NULL COMMENT 'The error code from batchfile ',
  `batchmodified` datetime NOT NULL COMMENT 'The timestamp of the last batchcode update ($timestamp = date("Y-m-d H:i:s"))',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19102 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `access_token` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`access_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_authorization_codes`
--

DROP TABLE IF EXISTS `oauth_authorization_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_authorization_codes` (
  `authorization_code` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `redirect_uri` varchar(2000) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`authorization_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_authorization_codes`
--

LOCK TABLES `oauth_authorization_codes` WRITE;
/*!40000 ALTER TABLE `oauth_authorization_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_authorization_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `client_id` varchar(80) NOT NULL,
  `client_secret` varchar(80) NOT NULL,
  `redirect_uri` varchar(2000) NOT NULL,
  `grant_types` varchar(80) DEFAULT NULL,
  `scope` varchar(100) DEFAULT NULL,
  `user_id` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES ('flexscore_mobile','a07042b4ce11e95d19977c354bebb1abdc036cba','http://fake/',NULL,NULL,NULL);
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_jwt`
--

DROP TABLE IF EXISTS `oauth_jwt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_jwt` (
  `client_id` varchar(80) NOT NULL,
  `subject` varchar(80) DEFAULT NULL,
  `public_key` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_jwt`
--

LOCK TABLES `oauth_jwt` WRITE;
/*!40000 ALTER TABLE `oauth_jwt` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_jwt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `refresh_token` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`refresh_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_scopes`
--

DROP TABLE IF EXISTS `oauth_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_scopes` (
  `scope` text,
  `is_default` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_scopes`
--

LOCK TABLES `oauth_scopes` WRITE;
/*!40000 ALTER TABLE `oauth_scopes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_scopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productandservice`
--

DROP TABLE IF EXISTS `productandservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productandservice` (
  `advisor_id` int(11) NOT NULL,
  `productserviceid` varchar(250) NOT NULL,
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `other` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=641 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `profileactionsteps`
--

DROP TABLE IF EXISTS `profileactionsteps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profileactionsteps` (
  `user_id` int(11) NOT NULL,
  `actionsteps` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `actionstatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lastmodifiedtime` date NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `profileactionsteps_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profileactionsteps`
--

LOCK TABLES `profileactionsteps` WRITE;
/*!40000 ALTER TABLE `profileactionsteps` DISABLE KEYS */;
/*!40000 ALTER TABLE `profileactionsteps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rolepermission`
--

DROP TABLE IF EXISTS `rolepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rolepermission` (
  `roleid` int(10) NOT NULL,
  `moduleid` int(10) NOT NULL,
  `permission` int(1) NOT NULL,
  `startdate` int(11) NOT NULL,
  `enddate` int(11) NOT NULL,
  PRIMARY KEY (`roleid`,`moduleid`),
  KEY `moduleid` (`moduleid`),
  CONSTRAINT `rolepermission_ibfk_1` FOREIGN KEY (`roleid`) REFERENCES `leapscoremeta`.`otlt` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `rolepermission_ibfk_3` FOREIGN KEY (`moduleid`) REFERENCES `leapscoremeta`.`otlt` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolepermission`
--

LOCK TABLES `rolepermission` WRITE;
/*!40000 ALTER TABLE `rolepermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `rolepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorechange`
--

DROP TABLE IF EXISTS `scorechange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scorechange` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `scorechange` text NOT NULL COMMENT 'score change for 180 days',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `patchstatus` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`user_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42945 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleid` int(4) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `zip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `isactive` enum('0','1','2') COLLATE utf8_unicode_ci NOT NULL COMMENT '0->Inactive, 1-Active and 2-Disabled',
  `resetpasswordcode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `resetpasswordexpiration` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'time that the reset password code will expire',
  `createdby` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `verificationcode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `verificationexpiration` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'time that the verification code will expire',
  `createdtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastaccesstimestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `requestinvitetokenkey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` int(10) DEFAULT NULL,
  `verified` tinyint(4) DEFAULT '0',
  `mailchimpstatus` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 - subscribed, 1 - unsubscribed, 2 - cleaned, 3 - deleted',
  `unsubscribecode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordupdated` tinyint(4) NOT NULL DEFAULT '0',
  `uidhashvalue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=47513 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccess`
--

DROP TABLE IF EXISTS `useraccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useraccess` (
  `id` int(16) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `attempt` tinyint(2) NOT NULL COMMENT '0=failed, 1=success',
  `authentication` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0-password, 1-pin',
  `accesstimestamp` datetime NOT NULL,
  `current` tinyint(2) NOT NULL COMMENT '0=false, 1=true',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18709 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usermedia`
--

DROP TABLE IF EXISTS `usermedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usermedia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(16) NOT NULL,
  `media_id` int(11) NOT NULL,
  `media_type` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19817 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usermedia`
--

LOCK TABLES `usermedia` WRITE;
/*!40000 ALTER TABLE `usermedia` DISABLE KEYS */;
/*!40000 ALTER TABLE `usermedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpersonalinfo`
--

DROP TABLE IF EXISTS `userpersonalinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpersonalinfo` (
  `user_id` int(11) NOT NULL,
  `userpic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` date DEFAULT NULL,
  `maritalstatus` enum('Single','Widowed','Married','Divorced','Domestic Union') COLLATE utf8_unicode_ci NOT NULL,
  `spouseage` date DEFAULT NULL,
  `noofchildren` int(3) DEFAULT '0',
  `childrensage` text COLLATE utf8_unicode_ci COMMENT 'Age would be Key value pair',
  `retirementstatus` tinyint(1) DEFAULT '0',
  `retirementage` int(3) NOT NULL DEFAULT '65',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `risk` decimal(5,2) DEFAULT NULL COMMENT 'This contains the risk factor selected by the user',
  `connectAccountPreference` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `debtsPreference` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `insurancePreference` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpersonalinfo`
--

LOCK TABLES `userpersonalinfo` WRITE;
/*!40000 ALTER TABLE `userpersonalinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpersonalinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userscore`
--

DROP TABLE IF EXISTS `userscore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userscore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(16) NOT NULL,
  `totalscore` int(4) DEFAULT '0',
  `montecarloprobability` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `scoredetails` longtext COMMENT 'SENGINE serialized object',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nintydays` int(11) NOT NULL,
  `montecarlo` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44218 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userscore`
--

LOCK TABLES `userscore` WRITE;
/*!40000 ALTER TABLE `userscore` DISABLE KEYS */;
/*!40000 ALTER TABLE `userscore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usersecurityanswer`
--

DROP TABLE IF EXISTS `usersecurityanswer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usersecurityanswer` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL,
  `createdtimestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modifiedtimestamp` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15034 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `yii_session`
--

DROP TABLE IF EXISTS `yii_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yii_session` (
  `id` char(32) NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yii_session`
--

LOCK TABLES `yii_session` WRITE;
/*!40000 ALTER TABLE `yii_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `yii_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-01-08 13:07:54
